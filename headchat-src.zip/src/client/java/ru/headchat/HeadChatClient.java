package ru.headchat;

import com.mojang.authlib.GameProfile;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.message.v1.ClientReceiveMessageEvents;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.PlayerInfo;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.contents.objects.PlayerSprite;
import net.minecraft.world.item.component.ResolvableProfile;

public class HeadChatClient implements ClientModInitializer {

    /** Ванильный таб уже показывает головы. Поставь true, если на твоём сервере их нет. */
    private static final boolean FORCE_TAB_HEADS = false;

    private static boolean tabWasModified = false;

    @Override
    public void onInitializeClient() {
        // Чат: голова перед каждым сообщением игрока
        ClientReceiveMessageEvents.ALLOW_CHAT.register((message, signed, sender, params, time) -> {
            if (sender == null) return true;
            Minecraft mc = Minecraft.getInstance();
            Component out = Component.empty().append(head(sender)).append(" ").append(message);
            mc.gui.getChat().addMessage(out);
            return false; // оригинал не показываем, чтобы не дублировался
        });

        // Таб: головы через отображаемое имя
        ClientTickEvents.END_CLIENT_TICK.register(mc -> {
            if (mc.getConnection() == null) return;
            if (FORCE_TAB_HEADS) {
                for (PlayerInfo info : mc.getConnection().getOnlinePlayers()) {
                    GameProfile p = info.getProfile();
                    info.setTabListDisplayName(Component.empty()
                            .append(head(p)).append(" ").append(p.name()));
                }
                tabWasModified = true;
            } else if (tabWasModified) {
                for (PlayerInfo info : mc.getConnection().getOnlinePlayers()) {
                    info.setTabListDisplayName(null);
                }
                tabWasModified = false;
            }
        });
    }

    private static Component head(GameProfile fallback) {
        Minecraft mc = Minecraft.getInstance();
        GameProfile profile = fallback;
        if (mc.getConnection() != null) {
            PlayerInfo info = mc.getConnection().getPlayerInfo(fallback.id());
            if (info != null) profile = info.getProfile();
        }
        return Component.object(new PlayerSprite(ResolvableProfile.createResolved(profile), true));
    }
}
